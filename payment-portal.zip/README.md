Payment Portal - One-click deploy (demo)
---------------------------------------
This project contains a React frontend and simple demo API under /api for Vercel Serverless Functions.
The demo uses data/demo.json for payments and messages so no external DB is required.

How to deploy:
1. Upload this repo to GitHub.
2. On Vercel: Import the repo. Framework: Vite. Build Command: `npm run build`. Output Dir: `dist`.
3. Deploy. The frontend will call /api/payments and /api/message automatically.

Demo logins are not implemented in this demo (simple public demo). For production, replace the demo API with real DB-backed endpoints.
