import React from 'react'
export default function MessageBox() {
  return <div>Message Box</div>
}