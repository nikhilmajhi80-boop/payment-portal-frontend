import React from 'react'
export default function Messages() {
  return <h1>Messages</h1>
}