import React from 'react'
export default function Login() {
  return <h1>Login Page</h1>
}