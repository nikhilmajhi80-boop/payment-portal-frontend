import React from 'react'
export default function Dashboard() {
  return <h1>Dashboard</h1>
}