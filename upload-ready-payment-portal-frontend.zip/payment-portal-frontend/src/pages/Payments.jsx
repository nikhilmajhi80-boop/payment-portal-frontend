import React from 'react'
export default function Payments() {
  return <h1>Payments</h1>
}