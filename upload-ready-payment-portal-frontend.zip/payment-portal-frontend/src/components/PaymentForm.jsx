import React from 'react'
export default function PaymentForm() {
  return <div>Payment Form</div>
}